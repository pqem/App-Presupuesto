# 🔄 Guía de Migración a PNPM

## 📋 ¿Qué incluye esta migración?

1. ✅ Script automático de migración
2. ✅ .gitignore actualizado para pnpm
3. ✅ Instrucciones claras paso a paso

---

## 🚀 OPCIÓN 1: Migración Automática (Recomendado)

### Pasos:

**1. Abre PowerShell en la carpeta del proyecto:**

```powershell
cd C:\Users\pablo\.gemini\antigravity\scratch\App-Presupuesto
```

**2. Descarga el script `migrate-to-pnpm.ps1` de los outputs**

**3. Ejecuta el script:**

```powershell
.\migrate-to-pnpm.ps1
```

Si te sale un error de "ejecución de scripts deshabilitada", ejecuta primero:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

Y luego vuelve a ejecutar el script.

**4. ¡Listo!** El script hará todo automáticamente:
- Instalará pnpm
- Eliminará node_modules y package-lock.json
- Instalará dependencias con pnpm
- Te mostrará un resumen

---

## 🔧 OPCIÓN 2: Migración Manual

Si prefieres hacerlo paso a paso:

### Paso 1: Instalar pnpm

```powershell
npm install -g pnpm
```

### Paso 2: Ir a tu proyecto

```powershell
cd C:\Users\pablo\.gemini\antigravity\scratch\App-Presupuesto
```

### Paso 3: Eliminar archivos de npm

```powershell
Remove-Item -Recurse -Force node_modules
Remove-Item -Force package-lock.json
```

### Paso 4: Instalar con pnpm

```powershell
pnpm install
```

### Paso 5: Actualizar .gitignore

Reemplaza tu `.gitignore` con el archivo `.gitignore` que está en los outputs.

---

## 📝 Nuevos comandos que usarás

| Antes (npm) | Ahora (pnpm) |
|-------------|--------------|
| `npm install` | `pnpm install` |
| `npm install react` | `pnpm add react` |
| `npm uninstall react` | `pnpm remove react` |
| `npm run dev` | `pnpm dev` |
| `npm run build` | `pnpm build` |
| `npm update` | `pnpm update` |

---

## ✅ Verificar que funcionó

Después de la migración, deberías ver:

1. ✅ Carpeta `node_modules` (pero más pequeña y con enlaces)
2. ✅ Archivo `pnpm-lock.yaml` (en lugar de package-lock.json)
3. ✅ NO debería haber `package-lock.json`

**Prueba que funciona:**

```powershell
pnpm dev
```

Deberías ver tu app corriendo en http://localhost:3000

---

## 🎯 Ventajas que vas a notar

1. ⚡ **Instalaciones más rápidas** (3x más rápido)
2. 💾 **Menos espacio en disco** (hasta 70% menos)
3. 🔒 **Más seguro** (estructura más estricta)
4. 🧹 **node_modules más limpio**

---

## 🔄 ¿Cómo subirlo a GitHub?

Después de la migración:

```bash
git add .
git commit -m "Migración de npm a pnpm"
git push origin main
```

**IMPORTANTE:** El archivo `pnpm-lock.yaml` SÍ debe subirse a GitHub (es como package-lock.json).

---

## ❓ Problemas comunes

### "pnpm no es reconocido como comando"

**Solución:** Cierra y vuelve a abrir PowerShell después de instalar pnpm.

### "Error al instalar dependencias"

**Solución:** Asegúrate de tener Node.js actualizado:

```powershell
node --version  # Debería ser v18 o superior
```

### "Algunos paquetes no funcionan"

**Solución:** La mayoría son compatibles, pero si tienes problemas con un paquete específico, puedes volver a npm:

```powershell
Remove-Item -Recurse -Force node_modules
Remove-Item -Force pnpm-lock.yaml
npm install
```

---

## 📊 Comparación de tamaño

**Antes (npm):**
- node_modules: ~300-400 MB

**Después (pnpm):**
- node_modules: ~50-80 MB (enlaces)
- Almacén global: ~300 MB (compartido entre proyectos)

Si tienes 5 proyectos similares:
- npm: 1.5-2 GB
- pnpm: ~300 MB + pequeños enlaces

**¡Ahorras más de 1 GB!** 🎉

---

## 🆘 ¿Necesitas ayuda?

Si algo no funciona, avísame y te ayudo a solucionarlo.

---

**¡Feliz coding con pnpm!** 🚀

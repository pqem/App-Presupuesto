# 🔄 Script de Migración de NPM a PNPM
# Este script automatiza completamente la migración

Write-Host "🚀 Iniciando migración de NPM a PNPM..." -ForegroundColor Cyan
Write-Host ""

# Paso 1: Verificar si estamos en el directorio correcto
$expectedPath = "App-Presupuesto"
$currentPath = (Get-Location).Path
if ($currentPath -notlike "*$expectedPath*") {
    Write-Host "❌ ERROR: Debes ejecutar este script desde la carpeta del proyecto" -ForegroundColor Red
    Write-Host "   Ubicación actual: $currentPath" -ForegroundColor Yellow
    Write-Host "   Ejecuta: cd C:\Users\pablo\.gemini\antigravity\scratch\App-Presupuesto" -ForegroundColor Yellow
    exit 1
}

Write-Host "✅ Directorio correcto verificado" -ForegroundColor Green
Write-Host ""

# Paso 2: Instalar pnpm globalmente
Write-Host "📦 Instalando pnpm globalmente..." -ForegroundColor Cyan
try {
    npm install -g pnpm
    Write-Host "✅ pnpm instalado correctamente" -ForegroundColor Green
} catch {
    Write-Host "❌ Error al instalar pnpm" -ForegroundColor Red
    exit 1
}
Write-Host ""

# Paso 3: Eliminar node_modules
Write-Host "🗑️  Eliminando node_modules..." -ForegroundColor Cyan
if (Test-Path "node_modules") {
    Remove-Item -Recurse -Force "node_modules"
    Write-Host "✅ node_modules eliminado" -ForegroundColor Green
} else {
    Write-Host "ℹ️  node_modules no existe (ya está limpio)" -ForegroundColor Yellow
}
Write-Host ""

# Paso 4: Eliminar package-lock.json
Write-Host "🗑️  Eliminando package-lock.json..." -ForegroundColor Cyan
if (Test-Path "package-lock.json") {
    Remove-Item -Force "package-lock.json"
    Write-Host "✅ package-lock.json eliminado" -ForegroundColor Green
} else {
    Write-Host "ℹ️  package-lock.json no existe" -ForegroundColor Yellow
}
Write-Host ""

# Paso 5: Instalar dependencias con pnpm
Write-Host "📥 Instalando dependencias con pnpm..." -ForegroundColor Cyan
Write-Host "   (Esto puede tardar 30-60 segundos)" -ForegroundColor Yellow
try {
    pnpm install
    Write-Host "✅ Dependencias instaladas con pnpm" -ForegroundColor Green
} catch {
    Write-Host "❌ Error al instalar dependencias" -ForegroundColor Red
    exit 1
}
Write-Host ""

# Paso 6: Verificar instalación
Write-Host "🔍 Verificando instalación..." -ForegroundColor Cyan
if (Test-Path "node_modules") {
    Write-Host "✅ node_modules creado correctamente" -ForegroundColor Green
} else {
    Write-Host "❌ ERROR: node_modules no fue creado" -ForegroundColor Red
    exit 1
}

if (Test-Path "pnpm-lock.yaml") {
    Write-Host "✅ pnpm-lock.yaml creado correctamente" -ForegroundColor Green
} else {
    Write-Host "❌ ERROR: pnpm-lock.yaml no fue creado" -ForegroundColor Red
    exit 1
}
Write-Host ""

# Resumen final
Write-Host "🎉 ¡MIGRACIÓN COMPLETADA EXITOSAMENTE!" -ForegroundColor Green
Write-Host ""
Write-Host "📊 Resumen:" -ForegroundColor Cyan
Write-Host "   ✅ pnpm instalado globalmente" -ForegroundColor White
Write-Host "   ✅ Archivos de npm eliminados" -ForegroundColor White
Write-Host "   ✅ Dependencias instaladas con pnpm" -ForegroundColor White
Write-Host "   ✅ pnpm-lock.yaml creado" -ForegroundColor White
Write-Host ""
Write-Host "🚀 Comandos que debes usar ahora:" -ForegroundColor Cyan
Write-Host "   pnpm dev          → Ejecutar en desarrollo" -ForegroundColor Yellow
Write-Host "   pnpm build        → Compilar para producción" -ForegroundColor Yellow
Write-Host "   pnpm add [pkg]    → Instalar nueva dependencia" -ForegroundColor Yellow
Write-Host "   pnpm remove [pkg] → Eliminar dependencia" -ForegroundColor Yellow
Write-Host ""
Write-Host "💡 Tip: Actualiza .gitignore para agregar pnpm-lock.yaml" -ForegroundColor Magenta
Write-Host ""
